<?php


class AnnuaireManager {

    private $pdo;

    function __construct($pdo){
        $this->pdo = $pdo;
    }
    
// Récupération des entrées de l'annuaire pour un client spécifique
    function getAnnuaireByClient($clientId) {
        $sql = "SELECT * FROM Annuaire WHERE clients_idclients = :clientId";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":clientId", $clientId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

// Importer un annuaire depuis un fichier CSV
    function importAnnuaireFromCSV($clientId, $filePath) {
        if (($handle = fopen($filePath, 'r')) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                $sql = "INSERT INTO Annuaire (clients_idclients, Nom, Adresse, Telephone, Email) 
                        VALUES (:clientId, :nom, :adresse, :telephone, :email)";
                $stmt = $this->pdo->prepare($sql);
                $stmt->bindParam(":clientId", $clientId, PDO::PARAM_INT);
                $stmt->bindParam(":nom", $data[0], PDO::PARAM_STR);
                $stmt->bindParam(":adresse", $data[1], PDO::PARAM_STR);
                $stmt->bindParam(":telephone", $data[2], PDO::PARAM_STR);
                $stmt->bindParam(":email", $data[3], PDO::PARAM_STR);
                $stmt->execute();
            }
            fclose($handle);
            return true;
        } else {
            return "Erreur lors de l'ouverture du fichier CSV.";
        }
    }

    function addEntry($clientId, $nom, $adresse, $telephone, $email) {
        $sql = "INSERT INTO Annuaire (clients_idclients, Nom, Adresse, Telephone, Email) 
                VALUES (:clientId, :nom, :adresse, :telephone, :email)";

        $stmt = $this->pdo->prepare($sql);
        
        $stmt->bindParam(":clientId", $clientId, PDO::PARAM_INT);
        $stmt->bindParam(":nom", $nom, PDO::PARAM_STR);
        $stmt->bindParam(":adresse", $adresse, PDO::PARAM_STR);
        $stmt->bindParam(":telephone", $telephone, PDO::PARAM_STR);
        $stmt->bindParam(":email", $email, PDO::PARAM_STR);
        return $stmt->execute();
    }

    function deleteEntry($entryId) {
        $sql = "DELETE FROM Annuaire WHERE idAnnuaire = :entryId";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(":entryId", $entryId, PDO::PARAM_INT);
        return $stmt->execute();
    }


}