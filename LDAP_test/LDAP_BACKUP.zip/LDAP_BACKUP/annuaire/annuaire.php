<?php
include("../database/Annuaire_request.php");
include("../database/db.php");
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Annuaires</title>
    <link rel="stylesheet" href="annuaire.css">
</head>
<body>

    <!-- Barre latérale -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <img src="../logo/Logo-ldap.png" alt="Logo" class="logo-sidebar">

            <?php
            //récupération de l'id client pour afficher le bon nom + vérification de l'id dans l'URL
            //Vérification de l'id dans l'URL
            if (isset($_GET['idclients'])) {
                $clientsId = intval($_GET['idclients']);
                $clientName = null;

                //recherche du client en fonction de l'id
                foreach ($clients as $client){
                    if ($client['idclients'] == $clientsId) {
                        $clientName = htmlspecialchars($client['Nom']);
                        break;
                    }
                }

                //affichage du nom correspondant a l'id
                if ($clientName) {
                    echo '<p>' . $clientName . '</p>';
                }   else {
                    echo '<p>client non trouvé.</p>';
                }
            }   else {
                echo "<p> Aucun idenifiant de client fourni.</P>";
                exit; //coupe l'éxecution si l'ID n'est pas défini
            }
            
            // echo '<p>' . htmlspecialchars($clientName) . '</p>'; 
            ?>
        </div>

    </aside>

    <!-- Contenu principal -->
    <main class="main-content">
        <header class="main-header">
            <h1>Administration des Annuaires</h1>
            <div class="action-buttons">
                <div class="button-container">
                    <button id="import-csv" class="action-button">Importer CSV</button>
                    <button id="export-csv" class="action-button">Exporter CSV</button>
                    <button id="add-contact" class="add-button">Ajouter un contact</button> 
                </div>
            </div>
        </header>

        <!-- Formulaire d'ajout manuel de contact (caché par défaut) -->
        <div id="add-contact-form" style="display: none; margin-top: 20px;">
            <h3>Ajouter un nouveau contact</h3>
            <form id="contact-form" method="post">
                <label for="firstname">Prénom :</label>
                <input type="text" id="firstname" name="firstname" required><br>

                <label for="lastname">Nom :</label>
                <input type="text" id="lastname" name="lastname" required><br>

                <label for="email">Email :</label>
                <input type="email" id="email" name="email" required><br>

                <label for="extension">Extension :</label>
                <input type="text" id="extension" name="extension"><br>

                <label for="code">Code :</label>
                <input type="text" id="code" name="code"><br>

                <button type="submit" class="add-button">Ajouter</button>
            </form>
        </div>

        <section class="table-section">
            <h3>Liste des Contacts</h3>
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" id="select-all"></th> 
                        <th>Prénom</th>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Extension</th>
                        <th>Code</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="contact-list">
                    <!-- Les contacts seront ajoutés dynamiquement -->

                </tbody>
            </table>
        </section>
    </main>
    <a href="javascript:history.back()" class="back-button">Revenir en arrière</a>

    <script src="annuaire.js"></script> 
    <script>
        // Gestion du formulaire Ajouter un contact
        document.getElementById('add-contact').addEventListener('click', () => {
            const form = document.getElementById('add-contact-form');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        });
    </script>
</body>
</html>
